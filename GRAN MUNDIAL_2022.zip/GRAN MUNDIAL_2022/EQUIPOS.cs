﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GRAN_MUNDIAL_2022
{
    class Equipo
    {
        public string nombre;

        public int PG;

        public int PP;

        public int PE;

        public int etapa;
    }

    class SEMIFINAL
    {
        public string nombre;

        public int PG;

        public int PP;

        public int PE;

        public int etapa;
    }

    class FINAL
    {
        public string nombre;

        public int PG;

        public int PP;

        public int PE;

        public int etapa;
    }
}
